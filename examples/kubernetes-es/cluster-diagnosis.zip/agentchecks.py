#!/usr/bin/env python
# Copyright (c) 2017 Covalent IO

import subprocess
import utils
import logging
log = logging.getLogger(__name__)

CONNECTION_ERROR = "grpc: addrConn.resetTransport failed to create" \
                   " client transport: connection error:"
CONNECTION_ERROR_2 = "panic: rpc error: code = Unknown desc ="


def check_pod_running_cb(nodes):
    """Checks whether at least one Covalent Agent is running in the cluster.

    Args:
        nodes -- list of nodes where the agent pod may be running

    Returns:
        True if successful, False otherwise.
    """
    ret_code = True
    for name, ready_status, status, node_name in \
            utils.get_pods_summarized_status_iterator("covalent-agent-"):
        if node_name not in nodes:
            log.error("Covalent Agent is running "
                      "on an unkown node {}".format(node_name))
        if status != utils.STATUS_RUNNING or ready_status != "1/1":
            log.error("pod {} running on {} has ready status"
                      " {} and status {}".format(
                         name,
                         node_name,
                         ready_status,
                         status))
            ret_code = False
            # Check whether there is a problem fetching the image.
            if status in ["ErrImagePull", "ImagePullBackOff"]:
                log.error("Kubernetes is unable to fetch the covalent-agent"
                          " image from the image-registry")
                # Check whether the covalent-customers-pull-secret is missing.
                cmd = "kubectl get secret covalent-customers-pull-secret" \
                      " -n kube-system &> /dev/null"
                try:
                    subprocess.check_output(cmd, shell=True)
                except subprocess.CalledProcessError as exc:
                    if exc.returncode != 0:
                        log.error("Hint: The covalent-customers-pull-secret"
                                  " Kubernetes secret is not present in "
                                  "the kube-system namespace. "
                                  "This is required to fetch images"
                                  " from the image-registry.")
                    else:
                        log.error(
                            "command to check existence of the "
                            "covalent-customers-pull-secret secret failed."
                            " error code: {} {}".format(
                                exc.returncode,
                                exc.output))
                else:
                    # No exception means that the secret exists.
                    # Check whether the covalent-customers-pull-secret is
                    # invalid.
                    cmd = "kubectl get events -n kube-system | grep " + \
                        name + "| grep \"Permission Denied\""
                    try:
                        subprocess.check_output(cmd, shell=True)
                    except subprocess.CalledProcessError as exc:
                        # Exception means that the root cause is not related
                        # to permissions.
                        log.error(
                            "command to fetch events has failed. "
                            "error code: {} {}".format(
                                exc.returncode,
                                exc.output))
                    else:
                        log.error(
                            "Hint: The covalent-customers-pull-secret"
                            " Kubernetes secret exists, but "
                            "is most likely invalid. The secret"
                            " is required for fetching images"
                            " from the image-registry."
                        )
            else:
                # Check whether there is problem connecting to the collector.
                cmd = "kubectl logs -n kube-system " + name
                output = ""
                try:
                    output = subprocess.check_output(cmd, shell=True)
                except subprocess.CalledProcessError as exc:
                    log.error(
                        "command to fetch covalent-agent logs has failed."
                        " error code: {} {}".format(
                            exc.returncode,
                            exc.output))
                else:
                    for line in output.decode().splitlines():
                        if CONNECTION_ERROR in line:
                            log.error(
                                "Hint: Please check connectivity to the "
                                "endpoint specified in the "
                                "COVALENT_API_ENDPOINT"
                                " environment variable")
                            # Print the exact log message
                            log.error(line)
                            break
                        if CONNECTION_ERROR_2 in line:
                            log.error(
                                "Hint: Please check connectivity to the "
                                "endpoint specified in the "
                                "COVALENT_API_ENDPOINT"
                                " environment variable and the covalent-api"
                                " secret")
                            # Print the exact log message
                            log.error(line)
                            break
        else:
            log.info("pod {} running on {} has {} pods ready"
                     " and status {}".format(
                         name,
                         node_name,
                         ready_status,
                         status))
            break
    else:
        log.warning("covalent-agent pod is not running on any of the "
                    "nodes: {}".format(nodes))
        ret_code = False

    return ret_code
