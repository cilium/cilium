#!/usr/bin/env python
# Copyright (c) 2017 Covalent IO

import agentchecks
import ciliumchecks
import exporterchecks
import k8schecks
import logging
import os
import sys
import utils
import sysdumpcollector
import argparse
import time

log = logging.getLogger(__name__)
CILIUM_CHECKS_ONLY = False
exit_code = 0


if __name__ == "__main__":
    if sys.version_info < (2, 7, 0):
        sys.stderr.write("You need python 2.7+ to run this script\n")
        sys.exit(1)

    parser = argparse.ArgumentParser(description='Cluster diagnosis tool.')
    parser.add_argument('--cilium-only',
                        help='Only diagnose cilium issues',
                        action='store_true')

    # Add an optional subparser for the sysdump command.
    # Optional subparsers are only supported in Python 3.3+.
    # Python 2.7 optional subparsers implementation has bugs,
    # which have not been fixed/backported.
    # To workaround the optional subparser bug, parse the args only if
    # one of the supported commands is present.
    if '-h' in sys.argv or '--help' in sys.argv or 'sysdump' in sys.argv:
        subparsers = parser.add_subparsers(dest='sysdump')
        subparsers.required = False
        parser_sysdump = subparsers.add_parser('sysdump',
                                               help='collect logs and other '
                                                    'useful information')
        parser_sysdump.add_argument('--since',
                                    help='Only return logs newer than a '
                                         'relative duration like 5s, 2m, or'
                                         ' 3h. Defaults to all logs.',
                                    default='12h')
        parser_sysdump.add_argument('--size-limit', type=int,
                                    help='size limit (bytes) for the '
                                         'collected logs',
                                    default=256*1024*1024)

    args = parser.parse_args()
    try:
        if args.cilium_only:
            CILIUM_CHECKS_ONLY = True
        if args.sysdump:
            sysdump_dir_name = "./covalent-sysdump-{}"\
                .format(time.strftime("%Y%m%d-%H%M%S"))
            if not os.path.exists(sysdump_dir_name):
                os.makedirs(sysdump_dir_name)
            sysdumpcollector = sysdumpcollector.SysdumpCollector(
                sysdump_dir_name,
                args.since,
                args.size_limit)
            sysdumpcollector.collect()
            sys.exit(0)
    except AttributeError:
        pass

    nodes = utils.get_nodes()
    k8s_check_grp = utils.ModuleCheckGroup("k8s")
    k8s_check_grp.add(
        utils.ModuleCheck(
            "check the kube-apiserver version",
            lambda: k8schecks.check_kube_apiserver_version_cb()))
    k8s_check_grp.add(
        utils.ModuleCheck(
            "check RBAC configuration",
            lambda: k8schecks.check_rbac_cb()))
    if not k8s_check_grp.run():
        exit_code = 1

    cilium_check_grp = utils.ModuleCheckGroup("cilium")
    cilium_check_grp.add(
        utils.ModuleCheck(
            "check whether pod is running",
            lambda: ciliumchecks.check_pod_running_cb(nodes)))
    cilium_check_grp.add(utils.ModuleCheck(
        "L3/4 visibility: check whether DropNotification is enabled",
        lambda: ciliumchecks.check_drop_notifications_enabled_cb()))
    cilium_check_grp.add(utils.ModuleCheck(
        "L3/4 visibility: check whether TraceNotification is enabled",
        lambda: ciliumchecks.check_trace_notifications_enabled_cb()))
    if not cilium_check_grp.run():
        exit_code = 1

    if CILIUM_CHECKS_ONLY:
        sys.exit(exit_code)

    covalent_exporter_check_grp = utils.ModuleCheckGroup("covalent-exporter")
    covalent_exporter_check_grp.add(
        utils.ModuleCheck(
            "check whether pod is running",
            lambda: exporterchecks.check_pod_running_cb(nodes)))
    if not covalent_exporter_check_grp.run():
        exit_code = 1

    covalent_agent_check_grp = utils.ModuleCheckGroup("covalent-agent")
    covalent_agent_check_grp.add(
        utils.ModuleCheck(
            "check whether pod is running",
            lambda: agentchecks.check_pod_running_cb(nodes)))
    if not covalent_agent_check_grp.run():
        exit_code = 1

    sys.exit(exit_code)
