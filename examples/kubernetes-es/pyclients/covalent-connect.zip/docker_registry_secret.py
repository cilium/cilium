#!/usr/bin/env python
# Copyright (c) 2018 Covalent IO

import logging
import subprocess
import sys


logging.basicConfig(format='%(message)s', level=logging.INFO)
logger = logging.getLogger()


SECRET_YAML_FORMAT = '''---
apiVersion: v1
kind: Secret
metadata:
  name: covalent-customers-pull-secret
  namespace: kube-system
data:
  .dockerconfigjson: {secret}
type: kubernetes.io/dockerconfigjson
---
'''


def delete_docker_registry_secret():
    COMMAND = "kubectl delete secret -n kube-system " \
              "covalent-customers-pull-secret"
    if logger.getEffectiveLevel() >= logging.INFO:
        COMMAND += " &> /dev/null"

    try:
        logger.debug("Executing command: {}".format(COMMAND))
        output = subprocess.check_output(COMMAND, stderr=subprocess.STDOUT,
                                         shell=True)
        logger.debug("Output:\n{}".format(output))
    except subprocess.CalledProcessError:
        pass


def create_docker_registry_secret(secret_string):
    # Delete the secret if it already exists, and then recreate it.
    delete_docker_registry_secret()
    COMMAND = "kubectl apply -f -"
    try:
        logger.debug("Executing command: {}".format(COMMAND))
        p = subprocess.Popen(COMMAND.split(" "),
                             stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
        output, err = p.communicate(input=SECRET_YAML_FORMAT.
                                    format(secret=secret_string).encode())
        logger.debug("Output:\n{}".format(output))
        if len(err) != 0:
            logger.debug("Error:\n{}".format(err))
    except subprocess.CalledProcessError as grepexc:
        logger.debug("error code: {} {}".format(grepexc.returncode,
                     grepexc.output))
        logger.error("Could not create the secret. Please contact"
                     " technical support.")
        sys.exit(1)
    COMMAND = "kubectl get secret covalent-customers-pull-secret " \
              "-n kube-system"
    try:
        logger.debug("Executing command: {}".format(COMMAND))
        p = subprocess.Popen(COMMAND.split(" "),
                             stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE)
        output, err = p.communicate()
        logger.debug("Output:\n{}".format(output))
        if len(err) != 0:
            logger.debug("Error:\n{}".format(err))
    except subprocess.CalledProcessError:
        logger.error("Could not create the docker registry secret, which is "
                     "used to fetch Covalent artifacts. Please contact "
                     "technical support.")
        sys.exit(1)
