#!/usr/bin/env python
# Copyright (c) 2017 Covalent IO

import docker_registry_secret
import logging
import os
import sys
import subprocess
import time
import utils
import argparse


logging.basicConfig(format='%(message)s', level=logging.INFO)
logger = logging.getLogger()


ERROR_RUN_DIAGNOSTIC_TOOL = "We encountered a problem while starting " \
                            "the Covalent components."
VERBOSE_MODE = False
MAX_STATUS_CHECK_ATTEMPTS = 12


class color:
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    DARKCYAN = '\033[36m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'


def print_preamble(step_id, total_steps):
    if not VERBOSE_MODE:
        return ""

    return "\n" + color.BOLD + "(" + str(step_id) + "/" + str(total_steps) + \
           ")" + color.END + " "


def run_cluster_diagnosis_tool():
    logger.error(ERROR_RUN_DIAGNOSTIC_TOOL)
    if os.path.isfile('cluster-diagnosis.zip'):
        choice = get_user_input("We can try to identify the problem by "
                                "running some diagnostics on your cluster."
                                " OK to proceed? (y/N): ").lower()
        if choice in ["yes", "y"]:
            subprocess.call(["python", "./cluster-diagnosis.zip"], shell=False)
    else:
        logger.info("Please download and run the cluster-diagnosis tool from"
                    " https://app.covalent.io/cluster-diagnosis.zip.")


def run_cluster_diagnosis_tool_for_cilium(force=False):
    if os.path.isfile('cluster-diagnosis.zip'):
        try:
            p = subprocess.Popen(["python", "./cluster-diagnosis.zip",
                                  "--cilium-only"],
                                 stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE)
            output, err = p.communicate()
        except subprocess.CalledProcessError as exc:
            logger.debug("error code: {} {}".format(exc.returncode,
                                                    exc.output))
            logger.error("{}Cilium has not been installed correctly."
                         " Please follow the cilium installation guide "
                         "(http://cilium.readthedocs.io/en/latest/kubernetes"
                         "/install/), or contact technical support."
                         .format(exc.output))
            if not force:
                sys.exit(1)
            else:
                logging.info("Ignoring cilium installation error due "
                             "to the force option.")
        else:
            if p.returncode != 0:
                logger.error("{}Cilium has not been installed correctly."
                             " Please follow the cilium installation guide "
                             "(http://cilium.readthedocs.io/en/latest/"
                             "kubernetes/install/), or contact technical"
                             " support.".format(output.decode()))
                if not force:
                    sys.exit(1)
                else:
                    logging.info("Ignoring cilium installation error due "
                                 "to the force option.")


def get_covalent_api_secret():
    """Fetches the Covalent API secret from the env variable.

    Returns:
        string: the Covalent API secret.
    """
    secret_string = os.environ.get("COVALENT_API_SECRET")
    if secret_string is not None and secret_string != "":
        return secret_string
    else:
        logger.error("ERROR: COVALENT_API_SECRET env variable is not set."
                     " Please go to " + color.BLUE +
                     "https://app.covalent.io" + color.END +
                     " and sign in to your account. Visit the "
                     "Clusters page and click on the button to add a cluster. "
                     "Please follow the instructions "
                     "mentioned on that page to run this tool.")
        sys.exit(1)


def get_docker_registry_secret():
    """Fetches the docker registry secret from the env variable.

    Returns:
        string: the docker registry secret.
    """
    secret_string = os.environ.get("DOCKER_REG_SECRET")
    if secret_string is not None and secret_string != "":
        return secret_string
    else:
        logger.error("ERROR: DOCKER_REG_SECRET env variable is not set."
                     " Please go to " + color.BLUE +
                     "https://app.covalent.io" + color.END +
                     " and sign in to your account. Visit the "
                     "Clusters page and click on the button to add a cluster. "
                     "Please follow the instructions "
                     "mentioned on that page to run this tool.")
        sys.exit(1)


def delete_covalent_api_secret():
    COMMAND = "kubectl delete secret -n kube-system covalent-api"
    if logger.getEffectiveLevel() >= logging.INFO:
        COMMAND += " &> /dev/null"

    try:
        logger.debug("Executing command: {}".format(COMMAND))
        output = subprocess.check_output(COMMAND, stderr=subprocess.STDOUT,
                                         shell=True)
        logger.debug("Output:\n{}".format(output))
    except subprocess.CalledProcessError:
        pass


def create_covalent_api_secret(secret_string):
    # Delete the secret if it already exists, and then recreate it.
    delete_covalent_api_secret()
    COMMAND = "kubectl create secret -n kube-system generic covalent-api " \
              "--from-literal=token=\"Bearer " + secret_string + "\""
    try:
        logger.debug("Executing command: {}".format(COMMAND))
        output = subprocess.check_output(COMMAND, stderr=subprocess.STDOUT,
                                         shell=True)
        logger.debug("Output:\n{}".format(output))
    except subprocess.CalledProcessError as grepexc:
        logger.debug("error code: {} {}".format(grepexc.returncode,
                     grepexc.output))
        logger.error("Could not create the secret. Please contact"
                     " technical support.")
        sys.exit(1)
    COMMAND = "kubectl get secret covalent-api -n kube-system"
    try:
        logger.debug("Executing command: {}".format(COMMAND))
        output = subprocess.check_output(COMMAND, stderr=subprocess.STDOUT,
                                         shell=True)
        logger.debug("Output:\n{}".format(output))
    except subprocess.CalledProcessError:
        logger.error("Could not create the Covalent Policy Manager "
                     "API secret. Please contact "
                     "technical support. Output:\n{}".format(output))
        sys.exit(1)


def cleanup_covalent_services():
    COMMAND = "kubectl delete -f " + FRONTEND_URI + "/covalent.yaml"
    if logger.getEffectiveLevel() >= logging.INFO:
        COMMAND += " &> /dev/null"
    try:
        logger.debug("Executing command: {}".format(COMMAND))
        output = subprocess.check_output(COMMAND, stderr=subprocess.STDOUT,
                                         shell=True)
        logger.debug("Output:\n{}".format(output))
    except subprocess.CalledProcessError:
        pass


def start_covalent_services():
    logger.info("Deploying Covalent components to your cluster ...")
    COMMAND = "kubectl apply -f " + FRONTEND_URI + "/covalent.yaml"
    try:
        logger.debug("Executing command: {}".format(COMMAND))
        output = subprocess.check_output(COMMAND, stderr=subprocess.STDOUT,
                                         shell=True)
        logger.debug("Output:\n{}".format(output))
    except subprocess.CalledProcessError as grepexc:
        logger.debug("error code: {} {}".format(grepexc.returncode,
                     grepexc.output))
        logger.error("Could not start Covalent components. "
                     "Please contact technical support.")
        sys.exit(1)

    attempt = 0
    while attempt < MAX_STATUS_CHECK_ATTEMPTS:
        need_to_sleep = False
        attempt += 1
        for name, ready_status, status, node_name in \
                utils.get_pods_status_iterator("covalent-exporter"):
            if status == utils.STATUS_CONTAINER_CREATING:
                need_to_sleep = True
        for name, ready_status, status, node_name in \
                utils.get_pods_status_iterator("covalent-agent"):
            if status == utils.STATUS_CONTAINER_CREATING:
                need_to_sleep = True
        if need_to_sleep:
            # The following log must be info level. Otherwise, the user might
            # get an impression that the tool is stuck in non-verbose mode.
            logger.info("Containers are being created. "
                        "Sleeping for 15 seconds ...")
            time.sleep(15)
        else:
            break
    logger.debug("Done.")


def check_health_of_covalent_services():
    logger.debug("Checking the health of covalent-exporter ...")
    for name, ready_status, status, node_name in \
            utils.get_pods_summarized_status_iterator("covalent-exporter"):
        if status != utils.STATUS_RUNNING or ready_status != "1/1":
            logger.debug("pod {} running on {} has ready status"
                         " {} and status {}".format(
                             name,
                             node_name,
                             ready_status,
                             status))
            run_cluster_diagnosis_tool()
            sys.exit(1)
    else:
        logger.debug("Done.")

    logger.debug("Checking the health of covalent-agent ...")
    for name, ready_status, status, node_name in \
            utils.get_pods_summarized_status_iterator("covalent-agent"):
        if status != utils.STATUS_RUNNING or ready_status != "1/1":
            logger.debug("pod {} running on {} has ready status"
                         " {} and status {}".format(
                             name,
                             node_name,
                             ready_status,
                             status))
            run_cluster_diagnosis_tool()
            sys.exit(1)
    else:
        logger.debug("Done.")


if __name__ == "__main__":
    # Support Python 2 and 3 input
    # Default to Python 3's input()
    get_user_input = input

    # If this is Python 2, use raw_input()
    if sys.version_info[:2] <= (2, 7):
        get_user_input = raw_input

    VERBOSE_MODE = False
    FRONTEND_URI = "https://app.covalent.io"
    parser = argparse.ArgumentParser(description='Connect a Kubernetes cluster'
                                                 ' to the Covalent Policy '
                                                 'Manager.',
                                     epilog='The tool requires two environment'
                                            ' variables to be set ('
                                            'COVALENT_API_SECRET: the secret '
                                            'used to uniquely identify the '
                                            'cluster; '
                                            'DOCKER_REG_SECRET: the secret'
                                            ' used to fetch docker registry'
                                            ' artifacts).')
    parser.add_argument('-v',
                        help='enable verbose mode',
                        action='store_true')
    parser.add_argument('--uri',
                        help='the frontend URI',
                        default=FRONTEND_URI)
    parser.add_argument('--disconnect',
                        help='disconnect the cluster from the Covalent '
                             'Policy Manager',
                        action='store_true')
    parser.add_argument('--force',
                        help='ignore errors and try to force the connection',
                        action='store_true')
    args = parser.parse_args()
    if args.v:
        VERBOSE_MODE = True

    if VERBOSE_MODE:
        logger.setLevel(logging.DEBUG)
    else:
        logging.info("You can run the tool with \"-v\" to see detailed "
                     "output.")
        logger.setLevel(logging.INFO)

    if args.disconnect:
        logger.info("Disconnecting the cluster from the Covalent Policy "
                    "Manager ...")
        cleanup_covalent_services()
        docker_registry_secret.delete_docker_registry_secret()
        delete_covalent_api_secret()
        logger.info("Done.")
        sys.exit(0)

    if args.uri:
        FRONTEND_URI = args.uri
        logger.info("Connecting cluster to " + FRONTEND_URI)

    step_id = 1
    total_steps = 7

    if not VERBOSE_MODE:
        logger.info("Checking whether cilium has been installed correctly."
                    " This may take 30-45 seconds ...")
    else:
        logger.debug(print_preamble(step_id, total_steps) +
                     "Running diagnostics to check whether cilium has been"
                     " installed correctly.")
    run_cluster_diagnosis_tool_for_cilium(args.force)
    if not VERBOSE_MODE:
        logger.info("Done.")
    else:
        logger.debug("Done.")
    step_id += 1

    logger.debug(print_preamble(step_id, total_steps) +
                 "Checking whether the Covalent Policy Manager API secret "
                 "has been provided by the user.")
    secret_string = get_covalent_api_secret()
    logger.debug("Done.")
    step_id += 1

    logger.debug(print_preamble(step_id, total_steps) +
                 "Checking whether the docker registry secret "
                 "has been provided by the user.")
    dr_secret_string = get_docker_registry_secret()
    logger.debug("Done.")
    step_id += 1

    logger.debug(print_preamble(step_id, total_steps) +
                 "Creating a Kubernetes secret that will be used by Covalent"
                 " to uniquely identify the cluster.")
    create_covalent_api_secret(secret_string)
    logger.debug("Done.")
    step_id += 1

    logger.debug(print_preamble(step_id, total_steps) +
                 "Creating a Kubernetes secret that will be used by Covalent"
                 " to fetch docker registry artifacts.")
    docker_registry_secret.create_docker_registry_secret(dr_secret_string)
    logger.debug("Done.")
    step_id += 1

    logger.debug(print_preamble(step_id, total_steps) +
                 "Cleaning up previously installed Covalent components,"
                 " if any. This process may take up to 60 seconds.")
    cleanup_covalent_services()
    logger.debug("Done.")
    step_id += 1

    logger.debug(print_preamble(step_id, total_steps) +
                 "Deploying Covalent components ... ")
    start_covalent_services()

    logger.info("Verifying that components are connected to the Covalent "
                "Policy Manager ...")
    check_health_of_covalent_services()
    step_id += 1

    logger.info("Success! Please go to " + color.BLUE +
                "https://app.covalent.io" + color.END +
                " to see your connected cluster.\n")
